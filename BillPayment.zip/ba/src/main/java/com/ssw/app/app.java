package com.ssw.app;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ssw.model.Product;
import com.ssw.utils.BillAppConstants;
import com.ssw.utils.CustomException;

public class app {

	final static Logger logger = Logger.getLogger(app.class);
	public static void main(String[] args) {
		try {
			// byte[] jsonData = Files.readAllBytes(Paths.get("Products.txt"));
			logger.info("Application Started");
			File file = new File(ClassLoader.getSystemClassLoader().getResource("Products.txt").getFile());
			byte[] jsonData = Files.readAllBytes(Paths.get(file.getPath()));
			if(jsonData.length == 0) {
				throw new CustomException(BillAppConstants.productListEmptyCode, BillAppConstants.productListEmptyMessage);
			}
			logger.info("File successfully read");
			ObjectMapper objectMapper = new ObjectMapper();
			
			TypeFactory typeFactory = objectMapper.getTypeFactory();
			List<Product> products = objectMapper.readValue(jsonData, typeFactory.constructCollectionType(List.class, Product.class));
			if(products.size() == 0) {
				throw new CustomException(BillAppConstants.productListEmptyCode, BillAppConstants.productListEmptyMessage);
			}
			BillProcessing bp = new BillProcessing();
			bp.processBill(products);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (CustomException ce) {
			System.out.println(ce.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
