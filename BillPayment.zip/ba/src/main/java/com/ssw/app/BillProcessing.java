package com.ssw.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ssw.model.Product;
import com.ssw.utils.BillAppConstants;
import com.ssw.utils.CustomException;

public class BillProcessing {

	final static Logger logger = Logger.getLogger(app.class);
	public void processBill(List<Product> products) throws CustomException {
		Map<Integer, List<Product>> categorizedProducts = new HashMap<Integer, List<Product>>();
		categorizedProducts = getCategorizedProduct(products);
		if(categorizedProducts.size() == 0) {
			throw new CustomException(BillAppConstants.customizedProductListEmptyCode, BillAppConstants.customizedProductListEmptyMessage);
		}
		generateBill(categorizedProducts);
	}
	
	private void generateBill(Map<Integer, List<Product>> categorizedProducts) {
		logger.info("Generating the bill");
		float totalPrice = 0.0f;
		float totalSalesTax = 0.0f;
		System.out.printf("%-30s", "Product");
		System.out.printf("%-15s", "Quantity");
		System.out.printf("%-10s", "Rate");
		System.out.printf("%-15s", "Price");
		System.out.printf("%-20s", "Sales Tax");
		for(Map.Entry<Integer, List<Product>> entry : categorizedProducts.entrySet()) {
			System.out.printf("\n");
			Product sampleProduct = entry.getValue().get(0);
			System.out.printf("%-30s", sampleProduct.getName());
			System.out.printf("%-15s", entry.getValue().size());
			System.out.printf("%-10s", sampleProduct.getCost());
			System.out.printf("%-15s", calculatePrice(entry.getValue().size(), sampleProduct.getCost()) );
			System.out.printf("%-20s", calculateSalesTax(entry.getValue().size(), sampleProduct.getCost(), sampleProduct.getProductCategory().getSalesTax()));
			totalPrice += calculatePrice(entry.getValue().size(), sampleProduct.getCost());
			totalSalesTax += calculateSalesTax(entry.getValue().size(), sampleProduct.getCost(), sampleProduct.getProductCategory().getSalesTax());
		}
		System.out.printf("\n\n");
		System.out.printf("%-15s", "Total Price");
		System.out.printf("%-20s", "Total Sales Tax");
		System.out.printf("%-15s", "Billing Amount");
		System.out.printf("\n");
		System.out.printf("%-15s", totalPrice);
		System.out.printf("%-20s", totalSalesTax);
		System.out.printf("%-15s", totalPrice +totalSalesTax);
		
	}

	private Map<Integer, List<Product>> getCategorizedProduct(List<Product> products) {
		logger.info("Categorizing the product list");
		Map<Integer, List<Product>> categorizedProducts = new HashMap<Integer, List<Product>>();
		for (Product product : products) {
			logger.debug(product.getId());
			if(categorizedProducts.containsKey(product.getId())) {
				categorizedProducts.get(product.getId()).add(product);
			} else {
				List<Product> prodList = new ArrayList<Product>();
				prodList.add(product);
				categorizedProducts.put(product.getId(), prodList);
			}
		}
		return categorizedProducts;
	}
	
	public float calculatePrice(int quantity, float cost) {
		return quantity * cost;
	}
	
	public double calculateSalesTax(int quantity, float cost, float salesTax) {
		// multiplying by 0.01 for percentage tax
		return quantity * cost * salesTax * 0.01;
	}
}
