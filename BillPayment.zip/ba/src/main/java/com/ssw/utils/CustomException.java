package com.ssw.utils;

public class CustomException extends Exception  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7526092573955687242L;
	
	private int exceptionCode;
	private String exceptionMessage;
	
	public CustomException (int exceptionCode, String exceptionMessage) {
		this.exceptionCode = exceptionCode;
		this.exceptionMessage = exceptionMessage;
	}
	
	public int getExceptionCode() {
		return exceptionCode;
	}
	public void setExceptionCode(int exceptionCode) {
		this.exceptionCode = exceptionCode;
	}
	public String getExceptionMessage() {
		return exceptionMessage;
	}
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
	
	@Override
	public String toString() {
		return "Exception Code : " + this.getExceptionCode() + " :: Exception Message : " + this.getExceptionMessage();
	}
}
