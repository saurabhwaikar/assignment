package com.ssw.utils;

public class BillAppConstants {

	/** Exception Codes */
	public static int productListEmptyCode = 1000;
	public static int customizedProductListEmptyCode = 1001;
	
	/** Exception Messages */
	public static String productListEmptyMessage = "Product List is Empty";
	public static String customizedProductListEmptyMessage = "Customized Product List is Empty";
}
