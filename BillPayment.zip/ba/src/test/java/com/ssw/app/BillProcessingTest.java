package com.ssw.app;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class BillProcessingTest {

	BillProcessing bp;
	
	@BeforeEach
	void initSetup() {
		bp = new BillProcessing();
	}
	
	
	@Test
	@DisplayName("Calculate Price")
	void testCalculatePrice() {
		float expected = 10;
		float actual = bp.calculatePrice(1, 10);
		assertEquals(expected, actual);
	}

	@Test
	@DisplayName("Calculate Sales tax")
	void testCalculateSalesTax() {
		float expected = 1;
		double actual = bp.calculateSalesTax(1, 10, 10);
		assertEquals(expected, actual);
	}

}
