package com.ssw.app;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class appTest {

	@Test
	@DisplayName("Product List Exists")
	void productListExists() {
		assertTrue(Files.exists(Paths.get("Products.txt")));
	}

}
